package edu.byu.cs.tweeter.client.observer;

public interface LoginObserver extends SignInObserver{
//    void loginSucceeded(User user, AuthToken authToken);
}
