package edu.byu.cs.tweeter.client.observer;

import edu.byu.cs.tweeter.model.domain.User;

public interface IGetFollowersObserver extends PagedObserver<User> {
//    void handleSuccess(List<User> followees, boolean hasMorePages);
}
