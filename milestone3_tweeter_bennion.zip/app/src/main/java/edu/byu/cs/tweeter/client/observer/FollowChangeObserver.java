package edu.byu.cs.tweeter.client.observer;

public interface FollowChangeObserver extends ServiceObserver{
    void handleEnableFollowButton();
}
