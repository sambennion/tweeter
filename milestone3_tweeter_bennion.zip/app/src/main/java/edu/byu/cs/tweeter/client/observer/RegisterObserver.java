package edu.byu.cs.tweeter.client.observer;

public interface RegisterObserver extends SignInObserver{
//    void registerSucceeded(User user, AuthToken authToken);
}
