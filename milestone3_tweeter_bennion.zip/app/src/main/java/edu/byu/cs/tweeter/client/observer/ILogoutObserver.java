package edu.byu.cs.tweeter.client.observer;

public interface ILogoutObserver extends ServiceObserver{
    void handleSuccess();
}
